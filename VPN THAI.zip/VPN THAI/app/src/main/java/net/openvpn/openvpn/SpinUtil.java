package net.openvpn.openvpn;

import android.content.Context; 
import android.view.LayoutInflater; 
import android.view.View; 
import android.view.ViewGroup; 
import android.widget.ArrayAdapter; 
import android.widget.ImageView; 
import android.widget.Spinner; 
import android.widget.TextView; 
import java.util.Arrays;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.*;

public class SpinUtil { 
	public static int get_spinner_count(Spinner var0) { 
		ArrayAdapter var1 = (ArrayAdapter)var0.getAdapter(); 
		return var1 == null ? 0 : var1.getCount(); 
	} 

	public static String[] get_spinner_list(Spinner var0) { 
		ArrayAdapter var1 = (ArrayAdapter)var0.getAdapter(); 
		if (var1 == null) { 
			return (String[])null; 
		} else { 
			int var2 = var1.getCount(); 
			String[] var3 = new String[var2]; 

			for(int var4 = 0; var4 < var2; ++var4) { 
				var3[var4] = (String)((String)var1.getItem(var4)); 
			} 

			return var3; 
		} 
	} 

	public static String get_spinner_list_item(Spinner var0, int var1) { 
		ArrayAdapter var2 = (ArrayAdapter)var0.getAdapter(); 
		return var2 == null ? (String)null : (String)((String)var2.getItem(var1)); 
	} 

	public static String get_spinner_selected_item(Spinner var0) { 
		return (String)var0.getSelectedItem(); 
	} 

	public static void set_spinner_selected_item(Spinner var0, String var1) { 
		if (var1 != null) { 
			String var2 = get_spinner_selected_item(var0); 
			if (var2 == null || !var1.equals(var2)) { 
				ArrayAdapter var3 = (ArrayAdapter)var0.getAdapter(); 
				int var4 = var3.getCount(); 

				for(int var5 = 0; var5 < var4; ++var5) { 
					if (var1.equals((String)var3.getItem(var5))) { 
						var0.setSelection(var5); 
					} 
				} 
			} 
		} 

	} 

	public static void show_spinner(Context var0, Spinner var1, String[] var2) { 
		if (var2 != null) { 
			String[] var3 = get_spinner_list(var1); 
			if (var3 == null || !Arrays.equals(var2, var3)) { 
				SpinUtil.SpinnerAdapter var4 = new SpinUtil.SpinnerAdapter(var0, var2); 
				var1.setAdapter(var4); 
			} 
		} 

	} 

	public static class SpinnerAdapter extends ArrayAdapter { 
		public SpinnerAdapter(Context var1, String[] var2) { 
			super(var1, 2130903117, var2); 
		} 

		public View getCustomView(int var1, View var2, ViewGroup var3) { 
			String var4 = this.getItem(var1); 


			View var5 = LayoutInflater.from(this.getContext()).inflate(R.layout.spinner_item, var3, false);
			ImageView imageView = (ImageView) var5.findViewById(R.id.spinner_icon);
			TextView var6 = (TextView)var5.findViewById(R.id.promo_text);  
			TextView textView = (TextView) var5.findViewById(R.id.text_drm_free);
			LinearLayout linearLayout = (LinearLayout) var5.findViewById(R.id.ServerLinearLayout);
			TranslateAnimation translateAnimation = new TranslateAnimation(300, 0, 0, 0);
            Animation alphaAnimation = new AlphaAnimation(0, 1);
            translateAnimation.setDuration(500);
            alphaAnimation.setDuration(1300);
            AnimationSet animation = new AnimationSet(true);
            animation.addAnimation(translateAnimation);
            animation.addAnimation(alphaAnimation);

			var6.setText(var4); 
			imageView.setImageResource(R.drawable.pt);


			if (var4.startsWith("CN_A")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.cn);
				textView.setBackgroundResource(R.drawable.ic_ais);
			} else if (var4.startsWith("CN_D")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.cn);
				textView.setBackgroundResource(R.drawable.ic_dtac);
			} else if (var4.startsWith("CN_T")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.cn);
				textView.setBackgroundResource(R.drawable.ic_true);
			} else if (var4.startsWith("CN")) {
				imageView.setImageResource(R.drawable.cn);

			} else if (var4.startsWith("HK_A")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.hk);
				textView.setBackgroundResource(R.drawable.ic_ais);
			} else if (var4.startsWith("HK_D")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.hk);
				textView.setBackgroundResource(R.drawable.ic_dtac);
			} else if (var4.startsWith("HK_T")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.hk);
				textView.setBackgroundResource(R.drawable.ic_true);
			} else if (var4.startsWith("HK")) {
				imageView.setImageResource(R.drawable.hk);

			} else if (var4.startsWith("IN_A")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.in);
				textView.setBackgroundResource(R.drawable.ic_ais);
			} else if (var4.startsWith("IN_D")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.in);
				textView.setBackgroundResource(R.drawable.ic_dtac);
			} else if (var4.startsWith("IN_T")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.in);
				textView.setBackgroundResource(R.drawable.ic_true);
			} else if (var4.startsWith("IN")) {
				imageView.setImageResource(R.drawable.in);

			} else if (var4.startsWith("KR_A")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.kr);
				textView.setBackgroundResource(R.drawable.ic_ais);
			} else if (var4.startsWith("KR_D")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.kr);
				textView.setBackgroundResource(R.drawable.ic_dtac);
			} else if (var4.startsWith("KR_T")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.kr);
				textView.setBackgroundResource(R.drawable.ic_true);
			} else if (var4.startsWith("KR")) {
				imageView.setImageResource(R.drawable.kr);

			} else if (var4.startsWith("LA_A")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.la);
				textView.setBackgroundResource(R.drawable.ic_ais);
			} else if (var4.startsWith("LA_D")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.la);
				textView.setBackgroundResource(R.drawable.ic_dtac);
			} else if (var4.startsWith("LA_T")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.la);
				textView.setBackgroundResource(R.drawable.ic_true);
			} else if (var4.startsWith("LA")) {
				imageView.setImageResource(R.drawable.la);

			} else if (var4.startsWith("MM_A")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.mm);
				textView.setBackgroundResource(R.drawable.ic_ais);
			} else if (var4.startsWith("MM_D")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.mm);
				textView.setBackgroundResource(R.drawable.ic_dtac);
			} else if (var4.startsWith("MM_T")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.mm);
				textView.setBackgroundResource(R.drawable.ic_true);
			} else if (var4.startsWith("MM")) {
				imageView.setImageResource(R.drawable.mm);

			} else if (var4.startsWith("PH_A")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.ph);
				textView.setBackgroundResource(R.drawable.ic_ais);
			} else if (var4.startsWith("PH_D")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.ph);
				textView.setBackgroundResource(R.drawable.ic_dtac);
			} else if (var4.startsWith("PH_T")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.ph);
				textView.setBackgroundResource(R.drawable.ic_true);
			} else if (var4.startsWith("PH")) {
				imageView.setImageResource(R.drawable.ph);

			} else if (var4.startsWith("SG_A")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.sg);
				textView.setBackgroundResource(R.drawable.ic_ais);
			} else if (var4.startsWith("SG_D")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.sg);
				textView.setBackgroundResource(R.drawable.ic_dtac);
			} else if (var4.startsWith("SG_T")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.sg);
				textView.setBackgroundResource(R.drawable.ic_true);
			} else if (var4.startsWith("SG")) {
				imageView.setImageResource(R.drawable.sg);

			} else if (var4.startsWith("JP_A")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.jp);
				textView.setBackgroundResource(R.drawable.ic_ais);
			} else if (var4.startsWith("JP_D")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.jp);
				textView.setBackgroundResource(R.drawable.ic_dtac);
			} else if (var4.startsWith("JP_T")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.jp);
				textView.setBackgroundResource(R.drawable.ic_true);
			} else if (var4.startsWith("JP")) {
				imageView.setImageResource(R.drawable.jp);

			} else if (var4.startsWith("TH_A")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.th);
				textView.setBackgroundResource(R.drawable.ic_ais);
			} else if (var4.startsWith("TH_D")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.th);
				textView.setBackgroundResource(R.drawable.ic_dtac);
			} else if (var4.startsWith("TH_T")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.th);
				textView.setBackgroundResource(R.drawable.ic_true);
			} else if (var4.startsWith("TH")) {
				imageView.setImageResource(R.drawable.th);

			} else if (var4.startsWith("UK_A")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.uk);
				textView.setBackgroundResource(R.drawable.ic_ais);
			} else if (var4.startsWith("UK_D")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.uk);
				textView.setBackgroundResource(R.drawable.ic_dtac);
			} else if (var4.startsWith("UK_T")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.uk);
				textView.setBackgroundResource(R.drawable.ic_true);
			} else if (var4.startsWith("UK")) {
				imageView.setImageResource(R.drawable.uk);

			} else if (var4.startsWith("US_A")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.us);
				textView.setBackgroundResource(R.drawable.ic_ais);
			} else if (var4.startsWith("US_D")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.us);
				textView.setBackgroundResource(R.drawable.ic_dtac);
			} else if (var4.startsWith("US_T")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.us);
				textView.setBackgroundResource(R.drawable.ic_true);
			} else if (var4.startsWith("US")) {
				imageView.setImageResource(R.drawable.us);

			} else if (var4.startsWith("VN_A")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.vn);
				textView.setBackgroundResource(R.drawable.ic_ais);
			} else if (var4.startsWith("VN_D")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.vn);
				textView.setBackgroundResource(R.drawable.ic_dtac);
			} else if (var4.startsWith("VN_T")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.vn);
				textView.setBackgroundResource(R.drawable.ic_true);
			} else if (var4.startsWith("VN")) {
				imageView.setImageResource(R.drawable.vn);
				
			} else if (var4.startsWith("VIP_A")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.vip);
				textView.setBackgroundResource(R.drawable.ic_ais);
			} else if (var4.startsWith("VIP_D")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.vip);
				textView.setBackgroundResource(R.drawable.ic_dtac);
			} else if (var4.startsWith("VIP_T")) { 
				textView.setText("");
				imageView.setImageResource(R.drawable.vip);
				textView.setBackgroundResource(R.drawable.ic_true);
			} else if (var4.startsWith("VIP")) {
				imageView.setImageResource(R.drawable.vip);

			} 
			linearLayout.startAnimation(animation);


			return var5; 
		} 

		@Override 
		public View getDropDownView(int var1, View var2, ViewGroup var3) { 
			return this.getCustomView(var1, var2, var3); 
		} 

		@Override 
		public String getItem(int var1) { 
			return (String)super.getItem(var1); 
		} 

		@Override 
		public View getView(int var1, View var2, ViewGroup var3) { 
			return this.getCustomView(var1, var2, var3); 
		} 
	} 
}
